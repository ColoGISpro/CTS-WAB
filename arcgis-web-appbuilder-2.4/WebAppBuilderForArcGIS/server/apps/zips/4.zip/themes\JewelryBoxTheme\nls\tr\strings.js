define({
  "_themeLabel": "Mücevher Kutusu Teması",
  "_layout_default": "Varsayılan Düzen",
  "_layout_layout1": "Düzen 1",
  "emptyDocablePanelTip": "Araç eklemek için Araç sekmesinde + düğmesine tıklayın. "
});