define({
  "_widgetLabel": "نبذة عن"
});