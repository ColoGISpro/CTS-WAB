define({
  "_themeLabel": "Tema för smyckeskrin",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Klicka på plusknappen (+) på fliken Widget om du vill lägga till en widget. "
});