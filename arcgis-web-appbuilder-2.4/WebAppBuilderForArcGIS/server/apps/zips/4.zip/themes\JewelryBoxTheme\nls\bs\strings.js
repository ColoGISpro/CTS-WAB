define({
  "_themeLabel": "Tema kutije s nakitom",
  "_layout_default": "Zadani izgled",
  "_layout_layout1": "Izgled 1",
  "emptyDocablePanelTip": "Kliknite na gumb + u kartici widgeta da biste dodali widget. "
});