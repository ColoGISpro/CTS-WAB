define({
  "_themeLabel": "ערכת נושא תיבת תכשיטים",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_layout1": "פריסה 1",
  "emptyDocablePanelTip": "לחץ על הלחצן + בלשונית 'וידג'ט' כדי להוסיף וידג'ט. "
});