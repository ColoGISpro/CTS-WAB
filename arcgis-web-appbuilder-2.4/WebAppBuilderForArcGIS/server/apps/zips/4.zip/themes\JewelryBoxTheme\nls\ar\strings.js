define({
  "_themeLabel": "موضوع مربع الضوء",
  "_layout_default": "تخطيط افتراضي",
  "_layout_layout1": "تخطيط 1",
  "emptyDocablePanelTip": "انقر على زر + في علامة تبويب عنصر واجهة المستخدم لإضافة عنصر واجهة مستخدم. "
});