define({
  "_widgetLabel": "Antraštės valdiklis",
  "signin": "Prisijungti",
  "signout": "Atsijungti",
  "about": "Apie",
  "signInTo": "Prisijungti į",
  "cantSignOutTip": "Ši funkcija veikiant peržiūros režimu negalima.",
  "more": "daugiau"
});