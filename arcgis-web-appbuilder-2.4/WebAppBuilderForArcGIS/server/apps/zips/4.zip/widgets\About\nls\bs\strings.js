define({
  "_widgetLabel": "Informacije"
});