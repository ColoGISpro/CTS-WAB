define({
  "group": "Nome",
  "openAll": "Abrir Todos no Painel",
  "dropDown": "Mostrar no Menu Suspenso",
  "noGroup": "Não há grupo de widget configurado.",
  "groupSetLabel": "Configurar propriedades de grupos do widget"
});