define({
  "_widgetLabel": "Info"
});