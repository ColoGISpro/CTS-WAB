define({
  "_widgetLabel": "Tentang"
});