define({
  "_themeLabel": "Motiv šperkovnice",
  "_layout_default": "Výchozí rozvržení",
  "_layout_layout1": "Rozvržení 1",
  "emptyDocablePanelTip": "Kliknutím na tlačítko + na kartě Widget. "
});