define({
  "_themeLabel": "Korurasiateema",
  "_layout_default": "Oletusasettelu",
  "_layout_layout1": "Asettelu 1",
  "emptyDocablePanelTip": "Lisää pienoisohjelma napsauttamalla + -painiketta Pienoisohjelma-välilehdellä. "
});