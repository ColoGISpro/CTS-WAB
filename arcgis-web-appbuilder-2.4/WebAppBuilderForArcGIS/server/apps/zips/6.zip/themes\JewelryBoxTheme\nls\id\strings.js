define({
  "_themeLabel": "Tema Jewelry Box",
  "_layout_default": "Tata Letak Default",
  "_layout_layout1": "Tata Letak 1",
  "emptyDocablePanelTip": "Klik tombol + di tab Widget untuk menambahkan sebuah widget. "
});