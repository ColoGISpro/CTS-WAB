define({
  "_widgetLabel": "बारे में"
});