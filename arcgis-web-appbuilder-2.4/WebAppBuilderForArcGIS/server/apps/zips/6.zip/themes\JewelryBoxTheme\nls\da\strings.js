define({
  "_themeLabel": "Smykkeskrinstema",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Klik på + knappen på Widget-fanen for at tilføje en widget. "
});