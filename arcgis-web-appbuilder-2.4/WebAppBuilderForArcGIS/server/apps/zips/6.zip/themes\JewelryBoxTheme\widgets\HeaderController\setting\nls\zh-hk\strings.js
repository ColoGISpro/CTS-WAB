define({
  "group": "名稱",
  "openAll": "面板中的“開啟所有”",
  "dropDown": "在下拉式功能表中顯示",
  "noGroup": "不存在 widget 群組集。",
  "groupSetLabel": "設定 widget 群組屬性"
});