define({
  "_themeLabel": "Tema do Jewelry Box",
  "_layout_default": "Layout Padrão",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Clique no botão + na guia Widget para adicionar um widget. "
});