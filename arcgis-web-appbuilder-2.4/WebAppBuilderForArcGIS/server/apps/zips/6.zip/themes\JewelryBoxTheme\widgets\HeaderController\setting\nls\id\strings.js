define({
  "group": "Nama",
  "openAll": "Buka Semua dalam Panel",
  "dropDown": "Tampilkan di Menu Drop-down",
  "noGroup": "Tidak ada aturan grup widget.",
  "groupSetLabel": "Tetapkan properti grup widget"
});