define({
  "_widgetLabel": "Informazioni"
});