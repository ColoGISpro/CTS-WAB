define({
  "_widgetLabel": "Πληροφορίες"
});