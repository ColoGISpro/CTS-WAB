define({
  "_themeLabel": "आभूषण बॉक्स थीम",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_layout1": "रूपरेखा 1",
  "emptyDocablePanelTip": "एक विजेट जोड़ने के लिए विजेट टैब में +बटन पर क्लिक करें। "
});