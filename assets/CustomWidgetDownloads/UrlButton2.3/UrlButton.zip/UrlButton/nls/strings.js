define({
  root: ({
    _widgetLabel: "URL Link Button"
  })
});
