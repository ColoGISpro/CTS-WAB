define({
  root: ({
    urllinkaddress: "Your Links Address",
    urllinkplaceholder: "http://www.esri.com",
    instructions: "Set the link address above. Optionally change the widgets name to the text you want to appear in the button tooltip. Optionally change the widgets icon as desired."
  })
});
