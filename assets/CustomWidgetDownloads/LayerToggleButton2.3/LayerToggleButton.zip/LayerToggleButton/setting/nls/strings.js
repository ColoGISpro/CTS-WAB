define({
  root: ({
    layerSelectorTitle: "Choose which layers will be toggled by the button.",
    instructions: "Choose a layer to toggle. Optionally change the widgets name to the text you want to appear in the button tooltip. Optionally change the widgets icon as desired."
  })
});
