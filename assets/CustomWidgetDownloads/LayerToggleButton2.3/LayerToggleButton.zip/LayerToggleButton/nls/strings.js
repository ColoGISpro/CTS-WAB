define({
  root: ({
    _widgetLabel: "Layer Toggle Button"
  })
});
