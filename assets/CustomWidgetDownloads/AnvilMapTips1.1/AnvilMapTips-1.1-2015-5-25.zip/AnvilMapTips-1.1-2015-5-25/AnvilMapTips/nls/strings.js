define({
  root: {
    _widgetLabel: 'Anvil',
    greeting: "Hello, Coyote!",
    loaded: 'loaded'
  },
  "es": true,
  "zh-cn": false
});
