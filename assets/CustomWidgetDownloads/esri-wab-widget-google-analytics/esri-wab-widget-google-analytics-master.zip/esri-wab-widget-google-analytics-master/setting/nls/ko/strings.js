﻿define({
    unit: "한_Unit_빠",
    style: "한_Style_빠"
});