﻿define({
    unit: "ø_Unit_å",
    style: "ø_Style_å"
});