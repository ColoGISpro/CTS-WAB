﻿define({
    unit: "Ă_Unit_ș",
    style: "Ă_Style_ș"
});