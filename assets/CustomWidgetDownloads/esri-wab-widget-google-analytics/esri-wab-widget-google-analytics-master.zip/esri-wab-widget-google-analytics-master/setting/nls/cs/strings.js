﻿define({
    unit: "Ř_Unit_ů",
    style: "Ř_Style_ů"
});