﻿define({
    unit: "Ж_Unit_Я",
    style: "Ж_Style_Я"
});