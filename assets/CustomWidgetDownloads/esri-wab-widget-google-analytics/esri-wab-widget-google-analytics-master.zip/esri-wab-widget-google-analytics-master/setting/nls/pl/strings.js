﻿define({
    unit: "ł_Unit_ą",
    style: "ł_Style_ą"
});