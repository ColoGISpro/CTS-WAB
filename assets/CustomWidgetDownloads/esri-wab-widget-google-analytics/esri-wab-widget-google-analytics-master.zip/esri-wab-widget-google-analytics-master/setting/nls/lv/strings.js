﻿define({
    unit: "ķ_Unit_ū",
    style: "ķ_Style_ū"
});