define({
  root: {
    widgetTitle: "Google Analytics" ,
    description: "Google Analytics"
  }
  // add supported locales below:
  // , "zh-cn": true
});
