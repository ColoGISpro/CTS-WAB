define({
  root: ({
    ok: "OK",
    cancel: "Cancel",
    preview: "Busy Indicator Preview",
    previewHint: "Click the image to update"
  })
});
