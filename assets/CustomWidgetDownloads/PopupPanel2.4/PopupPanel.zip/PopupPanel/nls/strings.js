define({
  root: ({
    _widgetLabel: "Popup Panel",
    previous: "Previous Feature",
    next: "Next Feature",
    clear: "Clear",
    cleartip: "Clear All Popup Results",
    clearsel: "Clear Selected",
    clearseltip: "Clear Selected Popup Results",
    selectfeatures: "Select Feature(s) in the map",
    widgetversion: 'Popup Panel Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
});
