define({
  root: ({
    closeonclear: "Close this widget when the popup is cleared",
    closeonstart: "Close this widget on widget startup",
  })
});
