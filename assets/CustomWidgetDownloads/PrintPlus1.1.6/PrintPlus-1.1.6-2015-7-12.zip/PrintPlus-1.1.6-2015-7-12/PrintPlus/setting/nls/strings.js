define({
	root: ({
		configText: "Configure this widget in the PrintPlus/config.json file."
  })
});
