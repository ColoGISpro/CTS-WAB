define({
  root: {
    titleSuffix: 'Version Info',
    widgetVersionLabel: 'Widget Version',
    wabVersionLabel: 'Widget is designed to run in Web AppBuilder version',
  },
  "zh-cn": false
});