define({
  root: {
    max: "1.0",
    min: "0.5",
    widgetOpacity: "Widget Opacity",
    sliderTooltip: "Click to change the opacity of the Widget"
  },
  "zh-cn": false
});