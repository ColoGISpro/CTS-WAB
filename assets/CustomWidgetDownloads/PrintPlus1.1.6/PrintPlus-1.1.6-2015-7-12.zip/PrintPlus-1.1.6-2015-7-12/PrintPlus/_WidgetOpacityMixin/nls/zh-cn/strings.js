﻿define({
  max: "1.0",
  min: "0.5",
  widgetOpacity: "???",
  showSlider: "???",
  hideSlider: "???"
});