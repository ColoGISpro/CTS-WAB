define(
   ({
    title: "Bendrinti",
    heading: "Bendrinti šį žemėlapį",
    url: "Žemėlapio nuoroda",
    embed: "Įterpti žemėlapį",
    extent: "Bendrinti esamo žemėlapio aprėptį",
    size: "Dydis (plotis / aukštis):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "El. paštas",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
