define(
   ({
    title: "共享",
    heading: "共享此地图",
    url: "地图链接",
    embed: "嵌入地图",
    extent: "共享当前地图范围",
    size: "大小(宽度/高度):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "电子邮件",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
