define(
   ({
    title: "Del",
    heading: "Del dette kartet",
    url: "Kartkobling",
    embed: "Bygg inn kart",
    extent: "Del gjeldende kartutstrekning",
    size: "Størrelse (bredde/høyde):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-post",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
