define(
   ({
    title: "Partilhar",
    heading: "Partilhar este mapa",
    url: "Ligação de Mapa",
    embed: "Integrar Mapa",
    extent: "Partilhar a atual extensão do mapa",
    size: "Tamanho (largura/altura):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "Correio Eletrónico",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
