define(
   ({
    title: "Udostępnij",
    heading: "Udostępnij tę mapę",
    url: "Łącze mapy",
    embed: "Osadź mapę",
    extent: "Udostępnij bieżący zasięg mapy",
    size: "Rozmiar (szerokość/wysokość):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
