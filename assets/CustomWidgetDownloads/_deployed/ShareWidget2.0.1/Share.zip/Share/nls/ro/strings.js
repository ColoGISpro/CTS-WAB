define(
   ({
    title: "Partajare",
    heading: "Partajare această hartă",
    url: "Link către hartă",
    embed: "Încorporare hartă",
    extent: "Partajare extindere curentă a hărţii",
    size: "Dimensiune (lăţime/înălţime):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
