define(
   ({
    title: "שתף",
    heading: "שתף מפה זו",
    url: "קישור למפה",
    embed: "הטמע את המפה",
    extent: "שתף את תיחום המפה הנוכחי",
    size: "גודל (רוחב/גובה):",
    facebookTooltip: "פייסבוק",
    twitterTooltip: "טוויטר",
    gplusTooltip: "Google Plus",
    emailTooltip: "שלח בדוא\"ל",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
