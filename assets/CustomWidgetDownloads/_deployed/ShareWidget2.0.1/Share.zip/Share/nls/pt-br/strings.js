define(
   ({
    title: "Compartilhar",
    heading: "Compartilhar este mapa",
    url: "Link do Mapa",
    embed: "Mapa Embutido",
    extent: "Compartilhar extensão do mapa atual",
    size: "Tamanho (largura/altura):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
