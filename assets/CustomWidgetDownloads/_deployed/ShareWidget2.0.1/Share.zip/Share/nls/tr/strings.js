define(
   ({
    title: "Paylaş",
    heading: "Bu haritayı paylaş",
    url: "Harita Bağlantısı",
    embed: "Haritayı Ekle",
    extent: "Geçerli harita uzantısını paylaş",
    size: "Boyut (genişlik/yükseklik):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-posta",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
