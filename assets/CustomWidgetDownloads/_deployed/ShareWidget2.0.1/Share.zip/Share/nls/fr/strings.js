define(
   ({
    title: "Partager",
    heading: "Partager cette carte",
    url: "Lien de la carte",
    embed: "Intégrer la carte",
    extent: "Partager l\'étendue actuelle de la carte",
    size: "Taille (largeur/hauteur) :",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "Adresse électronique",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
