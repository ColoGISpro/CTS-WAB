define(
   ({
    title: "Jaga",
    heading: "Jaga seda kaarti",
    url: "Kaardi link",
    embed: "Lisa kaart",
    extent: "Jaga praeguse kaardi kuvaulatust",
    size: "Suurus (laius/kõrgus):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "e-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
