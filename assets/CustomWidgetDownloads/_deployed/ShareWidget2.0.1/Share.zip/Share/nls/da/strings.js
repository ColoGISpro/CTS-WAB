define(
   ({
    title: "Del",
    heading: "Del dette kort",
    url: "Kort-link",
    embed: "Integrér kort",
    extent: "Del aktuelt kortområde",
    size: "Størrelse (bredde/højde):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
