define(
   ({
    title: "Dela",
    heading: "Dela den här kartan",
    url: "Kartlänk",
    embed: "Bädda in karta",
    extent: "Dela aktuell kartutbredning",
    size: "Storlek (bredd/höjd):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-post",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
