define(
   ({
    title: "공유",
    heading: "이 맵 공유",
    url: "맵 링크",
    embed: "맵 포함",
    extent: "현재 맵 범위 공유",
    size: "크기(너비/높이):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "이메일",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
