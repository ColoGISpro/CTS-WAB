define(
   ({
    title: "Опубликовать",
    heading: "Опубликовать эту карту",
    url: "Ссылка на карту",
    embed: "Внедрить карту",
    extent: "Опубликовать текущий экстент карты",
    size: "Размер (ширина/высота):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "Email",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
