define(
   ({
    title: "Jaa",
    heading: "Jaa tämä kartta",
    url: "Karttalinkki",
    embed: "Upota kartta",
    extent: "Jaa nykyisen kartan laajuus",
    size: "Koko (leveys/korkeus):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "Sähköposti",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
