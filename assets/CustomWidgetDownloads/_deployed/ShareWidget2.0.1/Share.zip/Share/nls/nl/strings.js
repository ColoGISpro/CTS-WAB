define(
   ({
    title: "Delen",
    heading: "Deze kaart delen",
    url: "Kaartkoppeling",
    embed: "Kaart inbedden",
    extent: "Huidige kaartextent delen",
    size: "Grootte (breedte/hoogte):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-mail",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
