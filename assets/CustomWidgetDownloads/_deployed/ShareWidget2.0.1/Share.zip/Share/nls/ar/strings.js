define(
   ({
    title: "مشاركة",
    heading: "مشاركة هذه الخريطة",
    url: "رابط الخريطة",
    embed: "تضمين الخريطة",
    extent: "مشاركة نطاق الخريطة الحالي",
    size: "الحجم (الاتساع/الارتفاع):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "البريد الإلكتروني",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
