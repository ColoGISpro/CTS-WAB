define(
   ({
    title: "แบ่งปัน",
    heading: "แชร์แผนที่นี้",
    url: "เชื่อมโยงแผนที่",
    embed: "ผูกติดกับแผนที่",
    extent: "แชร์ขอบเขตแผนที่ปัจจุบัน",
    size: "ขนาด (กว้าง/สูง):",
    facebookTooltip: "เฟซบุ๊ค",
    twitterTooltip: "ทวิตเตอร์",
    gplusTooltip: "กูเกิ้ลพลัส",
    emailTooltip: "อีเมล์",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
