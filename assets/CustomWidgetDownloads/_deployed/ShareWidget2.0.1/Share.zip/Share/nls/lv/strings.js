define(
   ({
    title: "Kopīgot",
    heading: "Koplietot šo karti",
    url: "Kartes saite",
    embed: "Iedarināt karti",
    extent: "Koplietot pašreizējo kartes pārklājumu",
    size: "Izmēri (platums/augstums):",
    facebookTooltip: "Facebook",
    twitterTooltip: "Twitter",
    gplusTooltip: "Google Plus",
    emailTooltip: "E-pasts",
    widgetversion: 'Share Widget Version Info',
    widgetverstr: 'Widget Version',
    wabversionmsg: 'Widget is designed to run in Web AppBuilder version'
  })
);
